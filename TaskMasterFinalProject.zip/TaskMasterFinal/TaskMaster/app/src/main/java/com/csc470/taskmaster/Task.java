package com.csc470.taskmaster;

/**
 * Created by Joe Barrett on 12/1/2017.
 */


/*
 * Copyright (c) 2016 Razeware LLC
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

import android.content.Context;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import android.content.Context;
import android.os.Environment;
import android.util.Log;
import android.widget.ArrayAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;

import static android.content.ContentValues.TAG;
import static android.view.ViewDebug.trace;

public class Task {
    private static MainActivity mainActivity;
    public String title;
    public String taskId;
    public String isDone;


    public static ArrayList<Task> getTasksFromFile(String filename, Context context){
        final ArrayList<Task> taskList = new ArrayList<>();

        try {
            // Load data
            String jsonString = loadJsonFromAsset(filename, context);
            JSONObject json = new JSONObject(jsonString);
            JSONArray Tasks = json.getJSONArray("Tasks");

            // Get Task objects from data
            for(int i = 0; i < Tasks.length(); i++){
                Task oldTask = new Task();
                oldTask.title = Tasks.getJSONObject(i).getString("title");
                oldTask.taskId = Tasks.getJSONObject(i).getString("taskId");
                oldTask.isDone = Tasks.getJSONObject(i).getString("isDone");

                taskList.add(oldTask);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return taskList;
    }

    private static String loadJsonFromAsset(String filename, Context context) {
        String json = null;
        File file = new File(context.getFilesDir(), filename);
        try {
            FileInputStream is = new FileInputStream(file);//context.getAssets().open(filename);
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }

    public static ArrayList<Task> addTask(ArrayList list, String t){
        Task n = new Task();
        n.title = t;
        n.taskId = "0";
        n.isDone = "false";
        list.add(n);
        return list;
    }
    public static ArrayList<Task> deleteTask(ArrayList list, int position){
        list.remove(position);
        return list;
    }
    public JSONObject getJSONObject() {
        JSONObject obj = new JSONObject();
        try {
            obj.put("title", title);
            obj.put("taskId", taskId);
            obj.put("isDone", isDone);
        } catch (JSONException e) {
            Log.e("Myapp", "unexpected JSON exception");
        }
        return obj;
    }

    public static String convertArrayListToJson(ArrayList<Task> list){
        String objStr = null;
        try
        {
            JSONArray jArry=new JSONArray();
            for (int i=0;i< list.size();i++)
            {
                JSONObject obj=new JSONObject();
                obj.put("title", list.get(i).title);
                obj.put("taskId", list.get(i).taskId);
                obj.put("isDone", list.get(i).isDone);
                jArry.put(obj);
            }
            JSONObject arrObj = new JSONObject();
            arrObj.put("Tasks", jArry);
            objStr = arrObj.toString();
            Log.d("test", objStr);
        }
        catch(JSONException ex){
            Log.e("object", "problem with objects");
            ex.printStackTrace();
        }
        return objStr;

    }
    public static void save(String filename, String objectString, Context ctx) {
        File file;
        FileOutputStream fop;
        try {

            file = new File(ctx.getFilesDir(),filename);
            fop = new FileOutputStream(file);

            // if file doesnt exists, then create it
            if (!file.exists()) {
                file.createNewFile();
            }

            // get the content in bytes
            byte[] contentInBytes = objectString.getBytes();

            fop.write(contentInBytes);
            fop.flush();
            fop.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
