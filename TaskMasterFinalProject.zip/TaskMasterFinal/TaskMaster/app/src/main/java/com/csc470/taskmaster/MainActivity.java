package com.csc470.taskmaster;

/**
 * Created by Joe Barrett on 12/1/2017.
 */

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Paint;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import android.support.design.widget.FloatingActionButton;
import static android.view.Gravity.CENTER;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import static android.view.Gravity.CENTER;

public class MainActivity extends AppCompatActivity {
    private ListView mListView;
    private ArrayList<Task> taskList;
    SharedPreferences prefs = null;
    private String filename = "tasklist";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        File file = new File(this.getFilesDir(), filename);
        if(!file.exists()){
            try{
                file.createNewFile();
            }catch(IOException e){
                Log.e("create file", "IO eception");
            }
        }

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);



        taskList = Task.getTasksFromFile("tasklist", this);

        mListView = (ListView) findViewById(R.id.task_list_view);
        populateList(taskList);



        final Context context = this;
        //Remove item
        mListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {

            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                final int pos = position;
                LayoutInflater inflater = (LayoutInflater)
                        context.getSystemService(LAYOUT_INFLATER_SERVICE);

                View customView = inflater.inflate(R.layout.task_delete_operations, null);

                final PopupWindow mPopupWindow = new PopupWindow(customView,
                        RelativeLayout.LayoutParams.WRAP_CONTENT,
                        RelativeLayout.LayoutParams.WRAP_CONTENT);



                Button closeButton = (Button)customView.findViewById(R.id.closeButton);
                closeButton.setOnClickListener(new Button.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        mPopupWindow.dismiss();
                    }
                });
                Button deleteButton = (Button)customView.findViewById(R.id.deleteButton);
                deleteButton.setOnClickListener(new Button.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        taskList = Task.deleteTask(taskList, pos);
                        populateList(taskList);
                        mPopupWindow.dismiss();
                    }
                });


                mPopupWindow.showAtLocation(findViewById(R.id.task_list_view),
                        CENTER,0, 0);
                return false;
            }

        });

        //cross out item
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                TextView text = (TextView) view;
                if((text.getPaintFlags() & Paint.STRIKE_THRU_TEXT_FLAG) >0){
                    text.setPaintFlags(text.getPaintFlags() & ~ Paint.STRIKE_THRU_TEXT_FLAG);
                }
                else {
                    text.setPaintFlags(text.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                }
            }

        });

        FloatingActionButton fab = (FloatingActionButton)findViewById(R.id.floatingActionButton);
        fab.setOnClickListener(new FloatingActionButton.OnClickListener(){
            @Override
            public void onClick(View view){


                LayoutInflater inflater2 = (LayoutInflater)getBaseContext()
                        .getSystemService(LAYOUT_INFLATER_SERVICE);

                View customView2 = inflater2.inflate(R.layout.task_add_operations,null);

                final PopupWindow mPopupWindow2 = new PopupWindow(customView2,
                        RelativeLayout.LayoutParams.WRAP_CONTENT,
                        RelativeLayout.LayoutParams.WRAP_CONTENT, true);

                final EditText text = (EditText) customView2.findViewById(R.id.editText);

                Button closeButton2 = (Button)customView2.findViewById(R.id.closeButton2);
                closeButton2.setOnClickListener(new Button.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        mPopupWindow2.dismiss();
                    }
                });

                Button addButton = (Button)customView2.findViewById(R.id.addButton);
                addButton.setOnClickListener(new Button.OnClickListener() {
                    @Override
                    public void onClick(View customView2) {

                        String title = text.getText().toString();
                        if (title.matches(".*\\w.*")) {
                            taskList = Task.addTask(taskList, title);
                            populateList(taskList);
                            mPopupWindow2.dismiss();
                        }

                        else {
                            title = "Field cannot be empty!";
                        }

                    }
                });


                mPopupWindow2.showAtLocation(findViewById(R.id.task_list_view),
                        CENTER,0, 0);
            }
        });
    }

    @Override
    /**public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }**/

    //@Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    protected void onPause(){
        super.onPause();
        Task.save("tasklist",
                Task.convertArrayListToJson(taskList),this);
    }

    public void populateList(ArrayList<Task> list){
        String[] strList = new String[list.size()];

        for(int i = 0; i < list.size(); i++){
            Task oldTask = list.get(i);
            strList[i] = oldTask.title;
        }
        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, strList);
        mListView.setAdapter(adapter);
    }
}


